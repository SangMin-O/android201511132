package com.example.pre11;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SubActivity extends AppCompatActivity {

    private final String dbName = "lesson";
    private final String tableName = "person";
    private static DBHandler instance = null;
    public static final int dbVersion = 1;

    int dbMode = Context.MODE_PRIVATE;

    private Context context;

    public Context getContext() {
        return this.context;
    }

    SQLiteDatabase sampleDB = null;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);
        Button button1 = (Button) findViewById(R.id.insertBtn) ;
        button1.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText nameText = (EditText) findViewById(R.id.name);
                EditText phoneText = (EditText) findViewById(R.id.phone);

                String name = nameText.getText().toString();
                String phone = phoneText.getText().toString();

                try {
                    DBHandler dbh = new DBHandler(MODE_PRIVATE);

                    dbh.onCreate(sampleDB);
                    Toast.makeText(context, "DB is opened", 0).show();
                    dbh.adding(sampleDB,1,1, name, phone);
                } catch (SQLiteException se) {
                    Toast.makeText(getApplicationContext(), se.getMessage(), Toast.LENGTH_LONG).show();
                    Log.e("", se.getMessage());
                }


                Intent intent=new Intent(SubActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

    }
}
