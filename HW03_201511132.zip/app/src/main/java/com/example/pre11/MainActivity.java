package com.example.pre11;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    SQLiteDatabase sampleDB = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageButton ib = (ImageButton) findViewById(R.id.imgBtn);

        ib.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, SubActivity.class));
            }
        });

        Button btn = (Button) findViewById(R.id.searchBtn);
        btn.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View view) {
                EditText searchNT = (EditText) findViewById(R.id.searchName);
                String searchName = searchNT.toString();
                try {
                    DBHandler dbh = new DBHandler(getBaseContext());
                    dbh.onCreate(sampleDB);
                    dbh.searching(sampleDB,1,1, searchName);
                } catch (SQLiteException se) {
                    Toast.makeText(getApplicationContext(), se.getMessage(), Toast.LENGTH_LONG).show();
                    Log.e("", se.getMessage());
                }catch (Exception e){
                    e.printStackTrace();
                }

            }
        });

    }

}
