package com.example.pre11;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.pre11.FeedReaderContract.FeedEntry;

public class DBHandler extends SQLiteOpenHelper {

    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "FeedReader.db";

    private static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE " + FeedEntry.TABLE_NAME + "(" +
                    FeedEntry._ID + " INTEGER PRIMARY KEY NOT NULL," +
                    FeedEntry.COLUMN_NAME + " TEXT ," +
                    FeedEntry.COLUMN_NUMBER + " TEXT )";

    private static final String SQL_SEARCH_ENTRIES1 =
            "SELECT "+FeedEntry.COLUMN_NAME+", "+FeedEntry.COLUMN_NUMBER
                    +" FROM " + FeedEntry.TABLE_NAME+" WHERE CONTAINS(" +FeedEntry.COLUMN_NAME+", '";
    private static final String SQL_SEARCH_ENTRIES2 = "')";
    private static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + FeedEntry.TABLE_NAME;

    private static final String SQL_INSERT_ENTRIES =
            "INSERT INTO "+ FeedEntry.TABLE_NAME +" ("+ FeedEntry.COLUMN_NAME +", "+ FeedEntry.COLUMN_NUMBER
                    + ") Values ('";
    public DBHandler(int context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_ENTRIES);
    }
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // This database is only a cache for online data, so its upgrade policy is
        // to simply to discard the data and start over

        db.execSQL(SQL_DELETE_ENTRIES);
        onCreate(db);
    }
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion);
    }

    public void adding(SQLiteDatabase db, int oldVersion, int newVersion,  String _NAME, String _NUM){
        String SQL_INSERT_FINE_ENTRIES = SQL_INSERT_ENTRIES + _NAME +"','"+_NUM +"');";
        db.execSQL(SQL_INSERT_FINE_ENTRIES);
    }

    public void searching(SQLiteDatabase db, int oldVersion, int newVersion,  String _STR){
        String SQL_SEARCH_ENTRIES = SQL_SEARCH_ENTRIES1 + _STR + SQL_SEARCH_ENTRIES2;
        db.execSQL(SQL_SEARCH_ENTRIES);
    }
}
